module RendererImpl (RenderErr, render) where

import Ast
import Data
import Control.Monad.Reader

type RenderErr = String
  -- (or something else, as long as it's an instance of Eq and Show

type EvalM a = Ctx -> Either RenderErr a
type ExecM a = (Ctx,Either RenderErr String) -> (Ctx,Either RenderErr String)

eval :: Exp -> EvalM Value -- do not change type! 
eval (ENum num) ctx = Right (N num)
eval (EPlus exp1 exp2) ctx= do
  v1<-eval exp1 ctx
  v2<-eval exp2 ctx
  case v1 of
    (N num1)-> case v2 of
      (N num2)-> Right (N (num1+num2))
      _->Left "Error happen in eval EPlus exp2"
    _->Left "Error happen in eval EPlus exp1"
eval (ELeq exp1 exp2) ctx= do
  v1<-eval exp1 ctx
  v2<-eval exp2 ctx
  case v1 of
    (N num1)-> case v2 of
      (N num2)-> if num1>num2 then Right (N 0) else Right  (N 1)
      _->Left "Error happen in eval ELeq exp2"
    _->Left "Error happen in eval ELeq exp1"
eval (EVar x) ctx= case lookup x ctx of
    Nothing -> Left "Not found"
    Just v->return v
eval (EField exp field) ctx= do
  v <-eval exp ctx
  case v of
    (R ctx)-> case lookup field ctx of
      Nothing-> Left "Not found in ctx"
      Just v-> return v
    _-> Left "No corresponding field value"

exec :: Template -> ExecM () -- do not change type!
exec [] (ctx,s)=  (ctx,s)
exec template (ctx,s)=  foldl updateResult (ctx,s) template

delFromAL :: Eq key => [(key, a)] -> key -> [(key, a)]
delFromAL l key = filter (\a -> fst a /= key) l
updateResult :: (Ctx,Either RenderErr String)->Frag->(Ctx,Either RenderErr String)
updateResult (ctx, Left err) frag=(ctx,Left err)
updateResult (ctx,Right s) (TLit s')= (ctx,Right $ s++s')
updateResult (ctx,Right s) (TOutput e)=case eval e ctx of
  Left err->(ctx,Left err)
  Right v->case v of
    (N num)->(ctx, Right $ s++show num)
    (S s1)->(ctx,Right $ s++s1)
    _-> (ctx,Left "TOutput handle error")
updateResult (ctx, Right s) (TAssign x e)=case eval e ctx of
  Left err-> (ctx,Left err)
  Right v->case lookup x ctx of
    Just a->((x,v):delFromAL ctx x,Right s)
    Nothing ->((x,v):ctx,Right s)
updateResult (ctx,Right s) (TIf e t1 t2)=case eval e ctx of
  Left err->(ctx,Left err)
  Right v-> case v of
    (N 0)->exec t2 (ctx,Right s)
    (N _)->exec t1 (ctx,Right s)
    (S "")->exec t2 (ctx,Right s)
    (S _)->exec t1 (ctx,Right s)
    (L [])->exec t2 (ctx,Right s)
    (L l)->exec t1 (ctx, Right s)
    (R _)->(ctx, Left "TIf handle error")
updateResult (ctx,Right s) (TFor x e t)=case eval e ctx of
  Left err->(ctx,Left err)
  Right v-> case v of
    (L [])->(ctx,Right s)
    -- (L l)-> case culErrOrLastResult $ foldl (\v ctx->exec t ((x,v):delFromAL ctx x,Right "")) (ctx,Right "") l of
    --   (Right s1)->case culErrOrResult $ map (\v->exec t ((x,v):delFromAL ctx x,Right "")) l of
    --     (Right s2)->((x,S s1 ):delFromAL ctx x,Right $  s++s2)
    --     (Left err)->(ctx,Left err)
    --   (Left err)->(ctx,Left err)
    (L l)-> case evalTFor (ctx,Right "") x t l of
      (Right s1)->((x,last l):delFromAL ctx x,Right $ s++s1)
      (Left err)->(ctx,Left err)
    _->(ctx,Left "Handle the TFor error")
updateResult (ctx,Right s)(TCapture x t)= case snd $ exec t (ctx,Right "") of
  (Right s')->((x,S s'):delFromAL ctx x,Right $ s++s')
  (Left err)->(ctx,Left err)

evalTFor::(Ctx,Either RenderErr String)->Ident->Template->[Value]->Either RenderErr String
evalTFor (ctx,Left err) x template l=Left err
evalTFor (ctx,Right s) x template []=Right s
evalTFor (ctx,Right s) x template (v:l)= case exec template ((x,v):delFromAL ctx x,Right s) of
  (ctx,Left err)->Left err
  (ctx,Right s')->evalTFor (ctx,Right s') x template l



render :: Ctx -> Template -> Either RenderErr String -- do not change type!
render ctx t =snd $ exec  t (ctx,Right "")
