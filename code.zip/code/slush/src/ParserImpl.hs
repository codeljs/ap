module ParserImpl where

import Ast
import Debug.Trace
import Data.Char ( isLetter, isNumber, isAscii, isSpace )
import Text.ParserCombinators.ReadP
import Text.Parsec.Char (letter)
import Control.Applicative((<|>))
type ParseErr = String
  -- (or something else, as long as it's an instance of Eq and Show

parseString :: String -> Either ParseErr Template -- do not change type!
parseString s= case readP_to_S (do; template<-pTemplate;eof;return template) s of
    [(s1,"")] -> Right s1
    _ -> Left "ParseError"

lexeme :: ReadP a -> ReadP a
lexeme p = do a <- p; whitespace; return a
whitespace :: ReadP ()
whitespace =
  skipMany $
    do satisfy (`elem` " \n\t"); return ()
whitespaces :: ReadP ()
whitespaces =
  skipMany1 $
    do satisfy (`elem` " \n\t"); return ()
pTemplate :: ReadP Template
pTemplate = many pFrag <++ return []
pFrag:: ReadP Frag
pFrag= pConditional <++ pCapture <++ pOutput <++ pIteration  <++ pAssignment <++ pLiteral
pLiteral :: ReadP Frag
pLiteral = TLit <$> literal
pOutput :: ReadP Frag
pOutput= do
  string "{{"
  whitespace
  exp<-pExp
  whitespace
  string "}}"
  return $ TOutput exp
pAssignment :: ReadP Frag
pAssignment = do
  string "{%"
  whitespace
  string "assign"
  whitespaces
  var<-ident
  whitespaces
  string "="
  -- traceM var
  -- traceM "debug2"
  whitespaces
  exp<-pExp
  -- traceM $ show $ TAssign var exp
  whitespace
  string "%}"
  return $ TAssign var exp
pConditional :: ReadP Frag
pConditional = do
  string "{%"
  whitespace
  string "if"
  whitespaces
  exp<-pExp
  whitespace
  string "%}"
  template<-pTemplate
  condRest<-pCondRest
  string "{%"
  whitespace
  string "endif"
  whitespace
  string "%}"
  case condRest of
    (Just t)-> return $ TIf exp template t
    Nothing -> return $ TIf exp template []
pCondRest :: ReadP (Maybe Template)
pCondRest =(do
  string "{%"
  whitespace
  string "else"
  whitespace
  string "%}"
  -- traceM "debug1"
  -- frag<- pFrag
  Just <$> pTemplate
  -- return $ Just [frag] 
  )
  <++
    (do
      string "{%"
      whitespace
      string "elsif"
      whitespaces
      exp<-pExp
      whitespace
      string "%}"
      template<-pTemplate
      condRest<-pCondRest
      case condRest of
        (Just t)->return $ Just [TIf exp template t]
        Nothing->return $ Just [TIf exp template []]
    )
  <++
      return Nothing

pIteration :: ReadP Frag
pIteration = do
  string "{%"
  whitespace
  string "for"
  whitespaces
  var<-ident
  whitespaces
  string "in"
  whitespaces
  exp<-pExp
  whitespace
  string "%}"
  template<-pTemplate
  string "{%"
  whitespace
  string "endfor"
  whitespace
  string "%}"
  return $ TFor var exp template
pCapture :: ReadP Frag
pCapture = do
  string "{%"
  whitespace
  string "capture"
  whitespaces
  var<-ident
  whitespace
  string "%}"
  template<-pTemplate
  string "{%"
  whitespace
  string "endcapture"
  whitespace
  string "%}"
  return $ TCapture var template
pEVar :: ReadP Exp
pEVar = EVar <$> ident
pENum :: ReadP Exp
pENum = ENum <$> numeral
pEClause :: ReadP Exp
pEClause = do
  string "("
  exp <-pExp
  string ")"
  return exp
pExp:: ReadP Exp
pExp = (do
  exp'<-pExp'
  whitespace
  string "<="
  whitespace
  ELeq exp' <$> pExp')
  <++ pExp'

pExp' :: ReadP Exp
pExp' = do
  exp2<-pExp2
  exp1<-pExp1
  case exp1 of
    Nothing->return exp2
    Just e->return $ e exp2

pExp1 :: ReadP (Maybe (Exp -> Exp))
pExp1= (do
  whitespace
  string "+"
  whitespace
  exp2<-pExp2
  exp1<-pExp1
  case exp1 of
    Nothing->return $ Just $ \e->EPlus e exp2
    Just e->return $ Just $ \e'->e (EPlus e' exp2)) <++ return Nothing

pExp2:: ReadP Exp
pExp2 = do
  exp3<-pExp3
  exp4<-pExp4
  case exp4 of
    Nothing -> return exp3
    Just exp4' -> return $  exp4' exp3

pExp3:: ReadP Exp
pExp3=pEClause <++ pEVar <++ pENum

pExp4:: ReadP (Maybe (Exp -> Exp))
pExp4 = (do
  string "."
  i<-ident
  exp4<-pExp4
  case exp4 of
    Nothing -> return $ Just $ \exp3 -> EField exp3 i
    Just e-> return $ Just $ \e'-> e (EField e' i) ) <++ return Nothing

literal :: ReadP String
literal = do
  char '{'
  char ' '
  s<-literal'
  return $ "{"++s
  <++
  (do
  s<-munch1 (/= '{')
  (do
    string "{"
    char ' '
    s'<- literal'
    return  $ s++"{"++s'
   )
   <++ return s)
literal' :: ReadP String
literal' = do
  s<-munch (/= '{')
  (do
    string "{"
    char ' '
    s'<- literal'
    return  $ s++"{"++s'
   )
   <++ return s

ident:: ReadP Ident
ident =
  do
    first <- satisfy isLetter
    rest <- munch (\c -> (isAscii  c && isLetter c)|| isNumber c || c == '_')
    return (first:rest)
numeral:: ReadP Int
numeral =
  do
    first <- satisfy (\c -> isNumber c|| c=='-')
    rest <- munch isNumber
    return (read (first:rest) ::Int)


