-- Do not modify this file! Put all your code in RendererImpl.hs

module Renderer
  (RenderErr, render)
where

import RendererImpl (RenderErr, render)
