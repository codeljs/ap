-- Do not modify this file! Put all your code in ParserImpl.hs

module Parser
 (ParseErr, parseString)
where

import Ast
import ParserImpl (parseString, ParseErr)


