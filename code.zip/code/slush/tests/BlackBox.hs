-- Rudimentary test suite. Feel free to replace anything.

import Ast
import Data

-- Do not import directly from ParserImpl or RendererImpl here; put
-- any white-box tests of internal functions in suite1/WhiteBox.hs
import Parser
import Renderer

import Test.Tasty
import Test.Tasty.HUnit
import Text.Parsec (parse)

main :: IO ()
main = defaultMain $ localOption (mkTimeout 1000000) tests

tests = testGroup "My Own tests" [
  testCase "parser" $
    parseString tms @?= Right tmp,
  testCase "Test literal 1" $
    parseString "{ hello" @?= Right [TLit "{hello"],
  testCase "Test literal 2" $
    parseString "hello }" @?= Right [TLit "hello }"],
  testCase "Test literal 3" $
    parseString "hello} {  .}  { } } world" @?= Right [TLit "hello} { .}  {} } world"],
  testCase "Test literal 4" $
    parseString "{ hello} {  .}  { } } world" @?=Right [TLit "{hello} { .}  {} } world"],
  testCase "Test literal 5" $
    parseString "You have ordered the following items:\n" @?= Right [TLit "You have ordered the following items:\n"],
  testCase "Test Output 1" $
    parseString "{{x+3+y}}" @?= Right [TOutput (EPlus (EPlus (EVar "x") (ENum 3)) (EVar "y"))],
  testCase "Test Output 2" $
    parseString "{{x+(3+y)<=x+(3+y)}}" @?= Right [TOutput (ELeq (EPlus (EVar "x") (EPlus (ENum 3) (EVar "y"))) (EPlus (EVar "x") (EPlus (ENum 3) (EVar "y"))))],
  testCase "Test OutPut 3" $
    parseString "{{x+3+y}}" @?=  Right [TOutput (EPlus (EPlus (EVar "x") (ENum 3)) (EVar "y"))],
  testCase "Test Output 4" $
    parseString "{{x<=y+z.u}}" @?= Right [TOutput (ELeq (EVar "x") (EPlus (EVar "y") (EField (EVar "z") "u")))],
  testCase "Test Output 5" $
    parseString "{{x<=y+z.u+w+(2<=3.c+1.v.u)}}" @?= Right [TOutput (ELeq (EVar "x") (EPlus (EPlus (EPlus (EVar "y") (EField (EVar "z") "u")) (EVar "w")) (ELeq (ENum 2) (EPlus (EField (ENum 3) "c") (EField (EField (ENum 1) "v") "u")))))],
  testCase "Test Conditional 1" $
    parseString "{% if x+0 %} hello {% else %}world{% endif %}" @?= Right [TIf (EPlus (EVar "x") (ENum 0)) [TLit " hello "] [TLit "world"]],
  testCase "Test Conditional 2" $
    parseString "{% if x<=1 %} love {% elsif x+1 %} haske11 {% endif %}" @?= Right [TIf (ELeq (EVar "x") (ENum 1)) [TLit " love "] [TIf (EPlus (EVar "x") (ENum 1)) [TLit " haske11 "] []]],
  testCase "Test Conditional 3" $
    parseString "{% if (x) %} I_want_to {% else %}sleep{% endif %}" @?= Right [TIf (EVar "x") [TLit " I_want_to "] [TLit "sleep"]],
  testCase "Test Conditional 4" $
    parseString "{% if x+69 %} pls_let_me {% elsif x<=56 %}pass_exam{% endif %}" @?= Right [TIf (EPlus (EVar "x") (ENum 69)) [TLit " pls_let_me "] [TIf (ELeq (EVar "x") (ENum 56)) [TLit "pass_exam"] []]],
  testCase "Test Conditional 5" $
    parseString "{% if x.niubijiashuo %} J1aShu0 {% else %} niubility {% endif %}" @?= Right [TIf (EField (EVar "x") "niubijiashuo") [TLit " J1aShu0 "] [TLit " niubility "]],
  testCase "Test Iteration 1" $
    parseString "{% for x in y+z %} hello {% endfor %}" @?=Right [TFor "x" (EPlus (EVar "y") (EVar "z")) [TLit " hello "]],
  testCase "Test Iteration 2" $
    parseString "{% for love in y<=2 %} hasikou {% endfor %}" @?= Right [TFor "love" (ELeq (EVar "y") (ENum 2)) [TLit " hasikou "]],
  testCase "Test Iteration 3" $
    parseString "{% for jiashuo in y.niubi %} jiashuo_niubi {% endfor %}" @?= Right [TFor "jiashuo" (EField (EVar "y") "niubi") [TLit " jiashuo_niubi "]],
  testCase "Test Iteration 4" $
    parseString "{% for doknow in x+1 %} what_to_spell {% endfor %}" @?= Right [TFor "doknow" (EPlus (EVar "x") (ENum 1)) [TLit " what_to_spell "]],
  testCase "Test Capture 1" $
    parseString "{% capture x %} hello {% endcapture %}" @?= Right [TCapture "x" [TLit " hello "]],
  testCase "Test Capture 2" $
    parseString "{% capture y %} {% for jiashuo in y.niubi %} jiashuo_niubi {% endfor %} {% endcapture %}" @?= Right [TCapture "y" [TLit " ",TFor "jiashuo" (EField (EVar "y") "niubi") [TLit " jiashuo_niubi "],TLit " "]],
  testCase "Test Capture 3" $
    parseString "{% capture z %} {% if x.niubijiashuo %} J1aShu0 {% else %} niubility {% endif %} {% endcapture %}" @?= Right [TCapture "z" [TLit " ",TIf (EField (EVar "x") "niubijiashuo") [TLit " J1aShu0 "] [TLit " niubility "],TLit " "]],
  testCase "Test Capture 4" $
    parseString "{% capture a %} {% capture b %} {% capture c %} hell0 {% endcapture %} {% endcapture %} {% endcapture %}" @?= Right [TCapture "a" [TLit " ",TCapture "b" [TLit " ",TCapture "c" [TLit " hell0 "],TLit " "],TLit " "]],
  testCase "Test Capture 5" $
    parseString "{% capture b %} {% if x<=1 %} {% capture z %} fxck {% endcapture %} {% elsif x+1 %} haske11 {% endif %} {% endcapture %}" @?= Right [TCapture "b" [TLit " ",TIf (ELeq (EVar "x") (ENum 1)) [TLit " ",TCapture "z" [TLit " fxck "],TLit " "] [TIf (EPlus (EVar "x") (ENum 1)) [TLit " haske11 "] []],TLit " "]],
  testCase "Test render 1" $
    render ctx tmp @?= Right out,
  testCase "Test Render 2" $
    render [("x", R [("niubijiashuo",N 2)] )] [TIf (EField (EVar "x") "niubijiashuo") [TLit " J1aShu0 "] [TLit " niubility "]] @?=Right " J1aShu0 ",
  testCase "Test Render 3" $
    render ctx2 tmp2 @?= Right out2,
  testCase "Test Render 4" $
    render [] [TCapture "x" [TLit " hello "]] @?=  Right " hello ",
  testCase "Test Render 5" $
    render ctx3 tmp3 @?= Right "  J1aShu0  "
  ]
  
  where
    tms = "Hello, {{user.first_name}}!\n"
    tmp = [TLit "Hello, ",
           TOutput (EField (EVar "user") "first_name"),
           TLit "!\n"]
    ctx = [("user", R [("first_name", S "John"), ("last_name", S "Doe")])]
    out = "Hello, John!\n"
    ctx2=  [("order", R [("client", S "John Smith"),
                ("items", L [R [("name", S "Universal widget"),
                                ("count", N 1)],
                             R [("name", S "Small gadget"),
                                ("count", N 10)]])])]
    tmp2=  [TIf (EField (EVar "order") "items")
       [TLit "You have ordered the following items:\n",
        TAssign "i" (ENum 0),
        TFor "item" (EField (EVar "order") "items")
             [TAssign "i" (EPlus (EVar "i") (ENum 1)),
              TLit "\n  ", TOutput (EVar "i"), TLit ". ",
              TOutput (EField (EVar "item") "name"),
              TIf (ELeq (ENum 2) (EField (EVar "item") "count"))
                  [TLit " (quantity ",
                   TOutput (EField (EVar "item") "count"),
                   TLit ")"]
                  [ ],
              TLit "\n"],
        TLit "\nThank you for shopping with us, ",
        TOutput (EField (EVar "order") "client"),
        TLit "!\n"]
       [TLit "You haven't ordered anything yet!\n"],
          TLit "\n"]
    out2="You have ordered the following items:\n\n  1. Universal widget\n\n  2. Small gadget (quantity 10)\n\nThank you for shopping with us, John Smith!\n\n"
    ctx3= [("x", R [("niubijiashuo", N 2)] )] 
    tmp3=[TCapture "z" [TLit " ",TIf (EField (EVar "x") "niubijiashuo") [TLit " J1aShu0 "] [TLit " niubility "],TLit " "]]