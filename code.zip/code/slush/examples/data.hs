  [("order", R [("client", S "John Smith"),
                ("items", L [R [("name", S "Universal widget"),
                                ("count", N 1)],
                             R [("name", S "Small gadget"),
                                ("count", N 10)]])])]
