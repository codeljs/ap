-module(twinners).
-export([setup/0, send_events/4, test_both/0]).

setup() ->
    {ok, Tony} = observable:new(),
    {ok, Robin} = observable:new(),
    {ok, John} = observable:new(),
    {ok, Alan} = observable:new(),
    {ok, Peter} = observable:new(),
    {ok, Barbara} = observable:new(),
    {ok, Leslie} = observable:new(),
    observable:add_subscriber(Robin, John, fun(X) -> 
                                            case is_integer(X) of
                                                true -> case X rem 2 of
                                                            0 -> true;
                                                            1 -> false 
                                                        end;
                                                false -> false
                                            end 
                                           end, 1),
    observable:add_subscriber(Tony, John, fun(_) -> true end, infinity),
    observable:add_subscriber(John, Peter, fun(_) -> true end, 2),
    observable:add_subscriber(John, Barbara, fun(List) -> 
                                               case is_list(List) of
                                                true -> case lists:nth(2, List) of
                                                            101 -> true;
                                                            _ -> false 
                                                        end;
                                                false -> false
                                                end
                                             end , infinity),
    observable:add_subscriber(Alan, Barbara, fun(_) -> true end, infinity),
    observable:add_subscriber(Barbara, Leslie, fun(_) -> true end, infinity),
    [Tony, Robin, John, Alan, Peter, Barbara, Leslie].

send_events(X, Y, W, Z) ->
    observable:publish(X, 5),
    observable:publish(X, 4),
    observable:publish(X, point),
    observable:publish(Y, "Hello"),
    observable:publish(W, {small, talk}),
    observable:publish(Z, liskov).

test_both() ->
    [_Tony, Robin, John, Alan, Peter, Barbara, Leslie] = setup(),
    send_events(Robin, John, Alan, Barbara),
    timer:sleep(30),
    {ok, EventLeslie} = observable:events(Leslie),
    {ok, EventPeter} = observable:events(Peter),
    (lists:sort(EventLeslie) == lists:sort([liskov,{small,talk},"Hello"])) and (lists:sort(EventPeter) == lists:sort(["Hello",4])).
  