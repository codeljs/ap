-module(test_observable).
-include_lib("eunit/include/eunit.hrl").
-export([test_all/0, test_everything/0]).


% You are allowed to split your testing code in as many files as you
% think is appropriate, just remember that they should all start with
% 'test_'.
% But you MUST have a module (this file) called test_observable.


test_all() ->
   eunit:test(
      [
       test_start_new_process(),
       test_repeated_new_process(),
       test_add1sub_right(),
       test_add1sub_infinite(),
       test_add1sub_wrong(),
       test_add_sub_to_sub(),
       test_subscriber_1(),
       test_subscriber_2(),
       test_publish_1(),
       test_event_1(),
       test_event_2(),
       test_event_3()
      ], [verbose]).

test_start_new_process()->
{ "Start a new server that does not exist",
  fun() ->
    ?assertMatch({ok, _}, observable:new())
  
  
  end
}.
  
test_repeated_new_process()->
{ "Start a new server that is already exist",
  fun() ->
    {ok, B} = observable:new(),
    ?assertNotMatch({ok, B}, observable:new())
  end
}.


test_add1sub_right()->
{ "add one sub to another, with right form",
  fun() ->
    {ok, C} = observable:new(),
    {ok, D} = observable:new(),
     ?assertMatch(ok, observable:add_subscriber(C,D, fun(X) -> X>0 end,100))
  
  
  end
}.
test_add1sub_infinite()->
{ "add one sub to another, with right form",
  fun() ->
    {ok, E} = observable:new(),
    {ok, F} = observable:new(),
     ?assertMatch(ok, observable:add_subscriber(E,F, fun(X) -> X>0 end,infinity))
  
  
  end
}.
test_add1sub_wrong()->
{ "add one sub to another, with wrong form",
  fun() ->
    {ok, G} = observable:new(),
    {ok, H} = observable:new(),
    ?assertMatch({error,_}, observable:add_subscriber(G,H, fun(X) -> X>0 end,-666))
  
  
  end
}.

test_add_sub_to_sub()->
{ "add one sub to another",
  fun() ->
    {ok, A1} = observable:new(),
    {ok, B1} = observable:new(),
    {ok, C1} = observable:new(),
    observable:add_subscriber(A1,B1, fun(X) -> X>0 end,100),
    ?assertMatch(ok, observable:add_subscriber(B1,C1, fun(X) -> X*(X-1)<0 end,100))
  
  
  end
}.

test_subscriber_1()->
{ "show subscribers",
  fun() ->
    {ok, A2} = observable:new(),
    {ok, B2} = observable:new(),
    {ok, C2} = observable:new(),
    observable:add_subscriber(A2,B2, fun(X) -> X>0 end,100),
    observable:add_subscriber(A2,C2, fun(X) -> X*(X-1)<0 end,infinity),
    ?assertMatch({ok,[B2,C2]}, observable:subscribers(A2))
  
  
  end
}.

test_subscriber_2()->
{ "show subscribers, with one faild subscriber",
  fun() ->
    {ok, A3} = observable:new(),
    {ok, B3} = observable:new(),
    {ok, C3} = observable:new(),
    observable:add_subscriber(A3,B3, fun(X) -> X>0 end,100),
    observable:add_subscriber(A3,C3, fun(X) -> X*(X-1)<0 end,-731),
    ?assertEqual({ok,[B3]}, observable:subscribers(A3))
  
  end
}.

test_publish_1()->
{ "publish event",
  fun() ->
    {ok, A4} = observable:new(),
    {ok, B4} = observable:new(),
    observable:add_subscriber(A4,B4, fun(X) -> X>0 end,11),
    ?assertEqual(ok,observable:publish(A4,5))
  
  end
}.
test_event_1()->
{ "show event",
  fun() ->
    {ok, A5} = observable:new(),
    {ok, B5} = observable:new(),
    {ok, C5} = observable:new(),
    observable:add_subscriber(A5,B5, fun(X) -> X>0 end,100),
    observable:add_subscriber(A5,C5, fun(X) -> X*(X-1)>0 end,-731),
    observable:publish(A5,5),
    timer:sleep(30),
    ?assertEqual({ok,[5]}, observable:events(B5))
  
  end
}.
test_event_2()->
{ "show event different with same value after multiple publish",
  fun() ->
    {ok, A6} = observable:new(),
    {ok, B6} = observable:new(),
    {ok, C6} = observable:new(),
    observable:add_subscriber(A6,B6, fun(X) -> X>0 end,100),
    observable:add_subscriber(B6,C6, fun(X) -> X*(X-1)>0 end,100),
    observable:publish(A6,5),
    observable:publish(B6,5),
    timer:sleep(30),
    ?assertEqual({ok,[5,5]}, observable:events(C6))
  
  end
}.

test_event_3()->
{ "show  same event after multiple publish",
  fun() ->
    {ok, A7} = observable:new(),
    {ok, B7} = observable:new(),
    {ok, C7} = observable:new(),
    {ok, D7} = observable:new(),
    observable:add_subscriber(A7,B7, fun(X) -> X>0 end,100),
    observable:add_subscriber(A7,C7, fun(X) -> X*(X-1)>0 end,100),
    observable:add_subscriber(B7,D7, fun(X) -> X>0 end,100),
    observable:add_subscriber(C7,D7, fun(X) -> X>0 end,100),
    observable:publish(A7,1000),
    timer:sleep(30),
    ?assertEqual({ok,[1000]}, observable:events(D7))
  
  end
}.





test_everything() ->
  test_all().
