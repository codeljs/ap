-module(observable).
-behaviour(gen_server).
-export([new/0, add_subscriber/4, subscribers/1, publish/2, events/1]).
-export([init/1, handle_call/3, handle_cast/2]).

%-type event()  ::{integer(),reference()}.
%-type events() ::[event()].
%-type subs_id() :: [pid()].

-type event()  ::term().
-type limit()  :: pos_integer() | infinity.
-type filter() :: fun((event()) -> boolean()).
-type sub()::{pid(),filter(),limit()} .
-type list_subs() ::[sub()].

-type reply_msg():: {error,any()}|{ok,any()}.
-type noreply_msg()::  {error,any()}|{ok,any()}.


-type request()::term().
-type from():: pid().
-type state()::term().
-type result()::term.

-spec new()->reply_msg().  %{ok,pid()}|{error, term()}  {ok,{Subscribers, Events}}
new() ->
  case gen_server:start(observable, [], []) of
        {ok, P}-> {ok, P};
        {error,Reason}  -> {error, Reason}
    end.

-spec add_subscriber(pid(),pid(),filter(),limit())-> reply_msg().
add_subscriber(P, S, Filt, Lim) ->
    case Lim of 
        infinity-> gen_server:call(P, {add, S, Filt, Lim});
        _-> case is_integer(Lim) of
                true -> case Lim > 0 of
                            true -> gen_server:call(P, {add, S, Filt, Lim});
                            false -> {error,"Wrong limit"}
                        end;
                false -> {error,"Wrong limit"}
            end
    end.
-spec subscribers(pid()) -> reply_msg(). % {ok,[<0.92.0>]}


subscribers(P) ->
    gen_server:call(P, {subscribers}).

-spec publish(pid(),event())->noreply_msg().  % ok
publish(P, E) ->
    gen_server:cast(P, {publish, E, make_ref()}).

-spec events(pid()) ->reply_msg().  %{ok,[5,a,a]}
events(P) ->
     gen_server:call(P, {events}).

-spec init(_)->reply_msg().
init(_) ->
    Subscribers = [],
    Events = [],
    {ok,{Subscribers, Events}}.

-spec handle_call(request(),from(),state()) ->reply_msg().
handle_call({add, S, Filt, Lim}, _From, {List, Events}) ->
    case lists:keyfind(S, 1, List) of
        false -> NewList = List ++ [{S, Filt, Lim}],
                 {reply, ok, {NewList, Events}};
        _-> {reply, {error, "Already subscribed"}, {List, Events}}
    end;

handle_call({subscribers}, _From, {List, Events}) ->
    {Subs, _, _} = lists:unzip3(List),
    {reply, {ok, Subs}, {List, Events}};

handle_call({events}, _From, {List, Events}) ->
    {Evs, _} = lists:unzip(Events),
    {reply, {ok, Evs}, {List, Events}}.

-spec handle_cast(request(),state()) ->noreply_msg().
handle_cast({publish, E, Ref}, {List, Events}) ->
    case lists:keyfind(Ref, 2, Events) of
        false -> NewList = publishEvent(E, Ref, List),
                 NewEvents = Events ++ [{E,Ref}],
                 {noreply, {NewList, NewEvents}};
        _ -> {noreply, {List, Events}}
    end.

-spec publishEvent(event(),reference(),list_subs())->result().
publishEvent(_, _, []) -> [];
publishEvent(E, Ref, [{S, Filt, Lim}|Rest]) ->
    case Filt(E) of
        true -> gen_server:cast(S, {publish, E, Ref}),
                case Lim of
                    infinity -> [{S, Filt, infinity}] ++ publishEvent(E, Ref, Rest);
                    _ -> case Lim - 1  of
                            0 -> publishEvent(E, Ref, Rest);
                            A -> [{S, Filt, A}] ++ publishEvent(E, Ref, Rest)
                        end
                end;
        _ -> [{S, Filt, Lim}] ++ publishEvent(E, Ref, Rest)
    end.

